
#include <stdio.h>

void reverseBits(int x){
    int i,a[1000],len=0;
    
    //converting decimal into binary
    for(i=0;x>0;i++)    
    {    
        a[i]=x%2;    
        x=x/2;
        len++;
    }    
    //printing binary value of given number
    printf("Before:");    
    for(i=i-1;i>=0;i--)    
    {    
        printf("%d",a[i]);    
    }    
    
    //printing in reverse order binary value of given number 
    printf(" After:");
    for(i=0;i<len;i++)    
    {    
        printf("%d",a[i]);    
    }
    
}

int main()
{
    int x;
    //getting input from user
    scanf("%d",&x);
    
    //calling reverseBits function 
    reverseBits(x);
    
    return 0;
}
