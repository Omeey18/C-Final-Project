#include <stdio.h>
int top=0;
char op[100];

//adding element in araay
void push(char x){
    
    //add element if previous element is not same 
    if(x != op[top]){
        top++;
        op[top] = x; 
    }
    //decrement top if previous element is same
    else{
        top--;
    }
}

int main()
{
    //getting lenght of string
    int len;
    scanf("%d",&len);
    
    //getting values of string 
    char in[len];
    scanf("%s",in);
    
    //calling push funation
    for(int i=0;i<len;i++){
        push(in[i]);
    }
    
    //output string is Empty then print Empty
    if(top==0){
        printf("Empty String");
    }
    
    //printing remaining single unique String
    else {
    for(int i=0;i<=top;i++){
        printf("%c",op[i]);
    }
    }
    return 0;
}
