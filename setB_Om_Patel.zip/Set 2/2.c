#include <stdio.h>
#include <string.h>

int main()
{   
    FILE * fdata;
    char c[1000];
    char son[100][100],father[100][100],grandfather[100];
    
    if ((fdata = fopen("file.txt", "r")) == NULL) 
    {
       printf("Error! File cannot be opened.");
    }
    
    for(int j=1;j<=5;j++)
    {
       while(fscanf(fdata,"%s %s",son[j],father[j])!=EOF)
       {
          break;
       }
   }
    
    int grandchildren_count=0,fatherPos,i;
    printf("Enter name : ");
    scanf("%s",grandfather);
    for(i=1;i<=5;i++)
    {
        if(strcmp(grandfather,father[i])==0)
        {
            fatherPos=i;
            for(int j=1;j<=5;j++)
            {
               if(strcmp(son[fatherPos],father[j])==0){
               grandchildren_count++;
            }

            }
        }
    }
    
    printf("%d\n",grandchildren_count);
    return 0;
}